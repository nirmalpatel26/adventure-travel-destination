[
    {
      "id": "1",
      "location": "Andaman & Nicobar",
      "capital": "Port Blair",
      "img": "https://dynamic.tourtravelworld.com/package-images/photo-big/dir_17/486726/202664.jpg",
      "place": [
        {
          "name": "NEIL ISLAND",
          "info": "Neil Island is one of India’s Andaman Islands, in the Bay of Bengal. Bharatpur Beach has coral reefs teeming with tropical fish. Laxmanpur Beach is known for its sunset views. Howrah Bridge is a natural rock formation accessible at low tide. Near the island’s wharf is Neil Kendra village, with a curving, sandy bay dotted with boats. Off the southeast coast, the tiny Sir Hugh Rose Island is a sanctuary for turtles.",
          "images": "https://uploads-ssl.webflow.com/5b56319971ac8c7475a9d877/5c4f5622a29a8f65c7f25f3e_IMG_7728%20Neil%20Island%20(21).jpg",
          "price": 19999,
          "package": "4 Nights / 5 Days",
          "category": "Beach",
          "rating": "9.2/10 Wonderful (1,009 reviews)",
          "rate": 9.2
        },
        {
          "name": "CELLULAR JAIL,PORT BLAIR",
          "info": "It has been an important historical part of Port Blair. Notable freedom fighters such as Veer Savarkar, Yogendra Shukla, Batukeshwar Dutt, and Babarao Savarkar were some of the inmates here. Don’t miss the light and sound show(Monday, Wednesday and Friday) when you visit Cellular jail. ",
          "images": "https://lh3.googleusercontent.com/p/AF1QipN1mdi9n1D_pUWX9puWYXdNRAqihXvWdUs7Z8nG=s1360-w1360-h1020",
          "price": 51000,
          "package": "4 Nights / 5 Days",
          "category": "Fort",
          "rating": "8.4/10 Excellent (469 reviews)",
          "rate": 8.4
        },
        {
          "name": "CORBYN'S COVE,PORT BLAIR",
          "info": "Surrounded by lush green palms, this happens to be one of the busier beaches in the Andamans. It’s located right outside of Port Blair about 8 km. The drive there itself is a scenic treat to the eyes.",
          "images": "https://live.staticflickr.com/982/40047849690_7a78e1f816_b.jpg",
          "price": 28999,
          "package": "6 Nights / 7 Days",
          "category": "Beach",
          "rating": "9.2/10 Wonderful (809 reviews)",
          "rate": 9.2
        },
        {
          "name": "SAMUDRIKA NAVAL MARINE MUSEUM,PORT BLAIR",
          "info": "This museum is a perfect blend of historical and modern Andaman. A massive blue whale, in its skeletal form, of course, greets you as you enter the museum. There is also an aquarium with fish of all shapes and sizes, from a parrotfish to the rare and venomous species of stonefish and corals.",
          "images": "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/12/3b/7e/4a/img-20180223-101229-largejpg.jpg?w=1400&h=-1&s=1",
          "price": 24057,
          "package": "6 Nights / 7 Days",
          "category": "Museum",
          "rating": "9.2/10 Wonderful (2,009 reviews)",
          "rate": 9.2
        },
        {
          "name": "HAVELOCK ISLAND(SWARAJ DWEEP)",
          "info": "Havelock Island is part of Ritchie’s Archipelago, in India’s Andaman Islands. It’s known for its dive sites and beaches, like Elephant Beach, with its coral reefs. Crescent-shaped Radhanagar Beach is a popular spot for watching the sunset. On the island’s east side, rocky sections mark long, tree-lined Vijaynagar Beach.",
          "images": "https://www.tripsavvy.com/thmb/SF7NoKaUPvXKxBkDbmPrC-GSddU=/2121x1414/filters:fill(auto,1)/GettyImages-508601155-592e840f5f9b5859500d0724.jpg",
          "price": 33499,
          "package": "6 Nights / 7 Days",
          "category": "Beach",
          "rating": "9.6/10 Wonderful (602 reviews)",
          "rate": 9.6
        }
      ]
    },
    {
      "id": "2",
      "location": "Punjab",
      "capital": "Chandigarh",
      "img": "https://bit.ly/2XjaMVx",
      "place": [
        {
          "name": "GOLDEN TEMPLE",
          "info": "The Golden Temple, also known as Harmandir Sahib or Darbār Sahib, is a Gurdwara located in the city of Amritsar, Punjab, India. It is the holiest Gurdwara and the most important pilgrimage site of Sikhism.The temple is built around a man-made pool (sarovar) that was completed by Guru Ram Das in 1577.Guru Arjan – the fifth Guru of Sikhism, requested Sai Mian Mir – a Muslim Pir of Lahore to lay its foundation stone in 1589.In 1604, Guru Arjan placed a copy of the Adi Granth in Harmandir Sahib, calling the site Ath Sath Tirath (lit. shrine of 68 pilgrimages).The temple was repeatedly rebuilt by the Sikhs after it became a target of persecution and was destroyed several times by the Muslim armies from Afghanistan and the Mughal Empire.The army led by Ahmad Shah Abdali, for example, demolished it in 1757 and again in 1762, then filled the pool with garbage and blood of cows.Maharaja Ranjit Singh after founding the Sikh Empire, rebuilt it in marble and copper in 1809, overlaid the sanctum with gold foil in 1830. This has led to the name the Golden Temple.",
          "images": "https://iptb.b-cdn.net/wp-content/uploads/2018/07/Golden-Temple-Punjab-1.jpg",
          "price": 9999,
          "package": "2 Nights / 3 Days",
          "category": "Temple",
          "rating": "9.8/10 Wonderful (12,000 reviews)",
          "rate": 9.2
        },
        {
          "name": "BHAKRA NANGAL DAM",
          "info": "Bhakra Dam is a concrete gravity dam on the Sutlej River in Bilaspur, Himachal Pradesh in northern India. The dam forms the Gobind Sagar reservoir.The dam, located at a gorge near the (now submerged) upstream Bhakra village in Bilaspur district of Himachal Pradesh of height 226 m. The length of the dam (measured from the road above it) is 518.25 m and the width is 9.1 m. Its reservoir known as 'Gobind Sagar' stores up to 9.34 billion cubic metres of water. The 90 km long reservoir created by the Bhakra Dam is spread over an area of 168.35 km2. In terms of quantity of water, it is the third largest reservoir in India, the first being Indira Sagar dam in Madhya Pradesh with capacity of 12.22 billion cu m and second Nagarjunasagar Dam.",
          "images": "https://akm-img-a-in.tosshub.com/indiatoday/images/bodyeditor/201810/dam647_081117121907_1-x404.jpg?9FIZpe39SqXGiX7EIroLsVdcLWjDaUeV",
          "price": 12499,
          "package": "6 Nights / 7 Days",
          "category": "Dam",
          "rating": "6.3/10 Good (119 reviews)",
          "rate": 6.3
        },
        {
          "name": "SUKHNA LAKE",
          "info": "Sukhna Lake in Chandigarh, India, is a reservoir at the foothills (Shivalik hills) of the Himalayas. This 3 km² rainfed lake was created in 1958 by damming the Sukhna Choe, a seasonal stream coming down from the Shivalik Hills. Originally the seasonal flow entered the lake directly causing heavy siltation. To check the inflow of silt, 25.42 km² of land was acquired in the catchment area and put under vegetation. In 1974, the Choe was diverted and made to bypass the lake completely, the lake being fed by three siltation pots, minimising the entry of silt into the lake itself.",
          "images": "https://www.trawell.in/admin/images/upload/472763834Chandigarh_Sukhna_Lake_Main.jpg",
          "price": 28099,
          "package": "5 Nights / 6 Days",
          "category": "Lake",
          "rating": "7.2/10 Very Good (756 reviews)",
          "rate": 7.2
        },
        {
          "name": "SHAHPUR KANDI FORT",
          "info": "The Shahpur Kandi Fort, named after Shah Jahan, nestles on the banks of the Ravi River in the picturesque foothills of the Himalayas. Located on the outer periphery of Pathankot, it was built in the 16th century, and stands surrounded by outstanding natural beauty. A part of the fort functions as a rest house today.Shahpur Kandi fort is located 7Kms from Pathankot and presently it has been converted into a beautiful rest house. It is named after Shah Jahan and was built by Bhao Singh in 16th Century. It is majestically located on the banks of river Ravi. There are a few small heritage monuments like tombs and a mosque.",
          "images": "https://trickytravellers.com/uploads/posts/f21bcbfd-9983-429c-8683-3aab6b08c549",
          "price": 25099,
          "package": "4 Nights / 5 Days",
          "category": "Fort",
          "rating": "7.2/10 very Good (789 reviews)",
          "rate": 7.2
        }
      ]
    },
    {
      "id": "3",
      "location": "Rajasthan",
      "capital": "Jaipur",
      "img": "https://upload.wikimedia.org/wikipedia/commons/0/09/Thar_Khuri.jpg",
      "place": [
        {
          "name": "Jaipur",
          "info": "Planned by Vidyadhar Bhattacharya, Jaipur holds the distinction of being the first planned city of India. Renowned globally for its coloured gems, the capital city of Rajasthan combines the allure of its ancient history with all the advantages of a metropolis. The bustling modern city is one of the three corners of the golden triangle that includes Delhi, Agra and Jaipur.The story goes that in 1876, the Prince of Wales visited India on a tour. Since the colour pink was symbolic of hospitality, Maharaja Ram Singh of Jaipur painted the entire city pink. The pink that colours the city makes for a marvellous spectacle to behold. Jaipur rises up majestically against the backdrop of the forts Nahargarh, Jaigarh and Garh Ganesh Temple.",
          "images": "https://images.thrillophilia.com/image/upload/s--QrPjqNho--/c_fill,f_auto,fl_strip_profile,h_775,q_auto,w_1600/v1/images/photos/000/046/475/original/1525775826_Jaipur_Main.jpg.jpg?1525775826",
          "price": 32000,
          "package": "5 Nights / 6 Days",
          "category": "Fort",
          "rating": "8.4/10 Excellent (409 reviews)",
          "rate": 8.4
        },
        {
          "name": "Amber Palace",
          "info": "Amber (pronounced Amer) is at a distance of about 11 kilometres from Jaipur. Now a UNESCO World Heritage Site, it was the bastion of the Kachwahas of Amber, until the capital was moved to the plains, to what is today Jaipur. The palace, located in craggy hills, is a beautiful melange of Hindu and Mughal styles. Raja Man Singh I began construction in 1592 and the palace, which was built as a strong, safe haven against attacking enemies, was completed by Mirja Raja Jai Singh.",
          "images": "https://images.thrillophilia.com/image/upload/s--UGQa1Iny--/c_fill,f_auto,fl_strip_profile,h_600,q_auto,w_975/v1/images/photos/000/110/813/original/1492513727_amber_fort_4.jpg.jpg?1492513727",
          "price": 30499,
          "package": "5 Nights / 6 Days",
          "category": "Fort",
          "rating": "9.2/10 Wonderful (1,109 reviews)",
          "rate": 9.2
        },
        {
          "name": "Jantar Mantar",
          "info": "Now a UNESCO World Heritage Site, Jantar Mantar in Jaipur is considered to be the largest of the five astronomical observatories built by Maharaja Sawai Jai Singh II, the founder of Jaipur. It contains sixteen geometric devices, designed to measure time, track celestial bodies and observe the orbits of the planets around the sun.",
          "images": "https://www.ritiriwaz.com/wp-content/uploads/2017/01/jantar-mantar.jpg",
          "price": 15099,
          "package": "3 Nights / 4 Days",
          "category": "Fort",
          "rating": "9.8/10 Wonderful (1,229 reviews)",
          "rate": 9.8
        },
        {
          "name": "Hawa Mahal",
          "info": "Hawa Mahal, literally the Palace of Winds, was built in 1799 by the poet king Sawai Pratap Singh as a summer retreat for him and his family. It also served as a place where the ladies of the royal household could observe everyday life without being seen themselves. This unique five-storey structure is a blend of Hindu and Islamic architecture, and the exterior, with its small latticed windows (called jharokhas), resembles the crown of Lord Krishna. The windows also serve as an air-conditioner of sorts, blowing cool air throughout the palace, making it the perfect retreat during summers.",
          "images": "https://www.holidify.com/images/bgImages/JAIPUR.jpg",
          "price": 18099,
          "package": "3 Nights / 4 Days",
          "category": "Fort",
          "rating": "9.7/10 Wonderful (2,299 reviews)",
          "rate": 9.7
        },
        {
          "name": "Albert Hall Museum(Central  Museum)",
          "info": "The building gets its name from The Victoria and Albert Museum in London, the inspiration for its design. The exquisitely built Albert Hall is housed in the centre of Ram Niwas Garden. Sir Swinton Jacob conceptualised and designed it using styles from the Indo-Sarcenic architecture and the Prince of Wales laid the foundation stone of the building in 1876.",
          "images": "https://live.staticflickr.com/2845/12542763994_d8b41967a3_b.jpg",
          "price": 12099,
          "package": "3 Nights / 4 Days",
          "category": "Museum",
          "rating": "7.8/10 Very Good (688 reviews)",
          "rate": 7.8
        },
        {
          "name": "Jal Mahal",
          "info": "One of the most wonderful sights in Jaipur is the beautiful Jal Mahal or Lake Palace. The light, sand coloured stone walls and the deep blue of the water make for a wonderful contrast. The palace appears to float in the centre of Man Sagar Lake, where its magnificent exteriors can be enjoyed by tourists.",
          "images": "https://upload.wikimedia.org/wikipedia/commons/6/6d/Jal_Mahal_in_Man_Sagar_Lake.jpg",
          "price": 10099,
          "package": "3 Nights / 4 Days",
          "category": "Lake",
          "rating": "9.0/10 Wonderful (978 reviews)",
          "rate": 9
        },
        {
          "name": "Chittorgarh Fort",
          "info": "The Chittor Fort or Chittorgarh is one of the largest forts in India. It is a UNESCO World Heritage Site. The fort was the capital of Mewar and is located in the present-day town of Chittor. It sprawls over a hill 180 m in height spread over an area of 280 ha above the plains of the valley drained by the Berach River.",
          "images": "https://www.chittorgarh.com/images/chittorgarh_fort.jpg",
          "price": 5000,
          "package": "3 Nights / 4 Days",
          "category": "Fort",
          "rating": "8.4/10 Excellent (409 reviewss)",
          "rate": 8.4
        },
        {
          "name": "Jaisalmer",
          "info": "Jaisalmer is a prominent tourist spot located in the northwestern state of Rajasthan in India. It is known as the 'golden city' due to its golden dunes and castles clad in golden honey sandstone. Jaisalmer is adorned with lakes, ornate Jain temples and havelis. Climb onto the camel saddle and make your way through this desert to camp under the starry night sky for an unforgettable experience.",
          "images": "https://rajputanacabs.b-cdn.net/wp-content/uploads/2019/08/Desert-Camps-Sam-Sand-Dunes-RJ.jpg",
          "price": 26000,
          "package": "3 Nights / 4 Days",
          "category": "Desert",
          "rating": "9.2/10 Wonderful (1,119 reviews)",
          "rate": 9.2
        },
        {
          "name": "Udaipur",
          "info": "Udaipur, also known as the City of Lakes, is one of the most visited tourist places in Rajasthan. Located around stunning water lakes and enveloped by the Aravalli Hills in all directions, Udaipur is known for its azure lakes, magnificent palaces, vibrant culture and delectable food. Along with being a must-visit destination, it is also one of the best places to experience luxury in India.",
          "images": "https://i.pinimg.com/564x/19/9e/b1/199eb18c88ea67e177fb34cd5f72cb15.jpg",
          "price": 8000,
          "package": "3 Nights / 4 Days",
          "category": "Lake",
          "rating": "9.5/10 Wonderful (2,039 reviews)",
          "rate": 9.5
        },
        {
          "name": "Thar Desert",
          "info": "Thar desert is 18th largest desert area in whole world, & is in both India & Pakistan. In the India’s site, you will find many sand dunes that have wild vegetation. but still there are around 7 desert dune area, that are authentic desert sites. When I use the term “authentic” I mean real desert sites in Rajasthan, where you will find sand dunes that are 20-50 meters tall, & many desert tourism related activities like Camel safari, Jeep safari, dune bashing, desert camping & in some places “Paragliding”",
          "images": "https://upload.wikimedia.org/wikipedia/commons/0/09/Thar_Khuri.jpg",
          "price": 23000,
          "package": "3 Nights / 4 Days",
          "category": "Desert",
          "rating": "9.2/10 Wonderful (1,109 reviews)",
          "rate": 9.2
        },
        {
          "name": "Pushkar",
          "info": "Pushkar is one of the holiest cities for the Hindus & a major tourist destination of Rajasthan, surrounded by desert sands. The sand dunes here are not as spectacular as that around Sam sand dunes Jaisalmer, but they are rated as the best places to go for exploring the rural village in Rajasthan. You can go on a camel ride here, or drive around in a camel cart to explore unseen regions of Thar Desert. The caretaker of the camel will be your guide & will share interesting facts about villages with you.",
          "images": "https://assets.traveltriangle.com/blog/wp-content/uploads/2017/09/Two-camels-in-the-desert-of-Rajasthan-ss290920017.jpg",
          "price": 18000,
          "package": "3 Nights / 4 Days",
          "category": "Desert",
          "rating": "8.4/10 Excellent (447 reviews)",
          "rate": 8.4
        }
      ]
    },
    {
      "id": "4",
      "location": "Kerala",
      "capital": "Thiruvananthapuram,",
      "img": "https://cdn.siasat.com/wp-content/uploads/2022/11/tourists-nov25.jpg",
      "place": [
        {
          "name": "Munnar",
          "info": "The idyllic hill station Munnar - famous for its tea estates, exotic lush greenery and craggy peaks, is located in the Western Ghats, in the state of Kerala. It serves as the commercial centre for some of the world’s largest tea estates. In addition, Munnar has many protected areas which are home to endemic and highly endangered species like the Nilgiri Thar and the Neelakurinji.One of the biggest tea-plantation area of South India, Munnar is one of the most beautiful and popular hill-stations of Kerala. Situated on the banks of three rivers- Madupetti, Nallathanni and Periavaru, Munnar is also blessed with natural view-points apart from the tea-plantations. Munnar is divided into Old Munnar, where the tourist information office is, and Munnar, where the bus station and most guest houses are located. The Eravikulam National Park, Salim Ali Bird Sanctuary and tea plantations are its major attractions.",
          "images": "https://images.thrillophilia.com/image/upload/s---dSM_iYr--/c_fill,f_auto,fl_strip_profile,g_auto,h_600,q_auto,w_975/v1/images/photos/000/126/889/original/1522671846_Munnar.jpg.jpg?1522671846",
          "price": 10099,
          "package": "3 Nights / 4 Days",
          "category": "Hills",
          "rating": "6.5/10 Good (679 reviews)",
          "rate": 6.5
        },
        {
          "name": "Alleppey",
          "info": "Allepey is also popular for its Houseboat cruises that pass through the serene backwaters, where you can catch glimpses of green paddy fields, choir making activities, beautiful avifauna and witness the life of locals in Kerala. Towards the shore lies the Alleppey beach in the Arabian Sea, a beautiful example of the gems you’d find along the Malabar Coast. The appeal of this beach is only amplified by the history attached to it, and a walk down the 137-year old pier is a must. Be sure to catch a traditional snake boat race in the months of August and September and try out some toddy (palm wine) at a local toddy shop for adding a touch of authenticity to your travel experience in Allepey.",
          "images": "https://miro.medium.com/max/2560/1*MjHGGH7V_SeoC9t2zmC-lA.jpeg",
          "price": 15000,
          "package": "3 Nights / 4 Days",
          "category": "Hills",
          "rating": "5.5/10 Average (229 reviews)",
          "rate": 5.5
        },
        {
          "name": "Wayanad",
          "info": "Wayanad is best known for the wildlife reserves - Wayanad wildlife reserve which is home to an exquisite variety of flora and fauna. Wayanad wildlife reserve is an integral part of the Nilgiri biosphere reserve peacefully located amidst the serene hills of Western Ghats. Wayanad homes a wide variety of wildlife like elephants, leopards, and bears. Wayanad is a perfect weekend idea from the cities of South India. If taking a road trip from Bangalore, you will drive through three national parks: Nagarhole, Bandipur and Mudumalai.",
          "images": "https://www.wayanad.com/files/slides/3253378071.jpg",
          "price": 17100,
          "package": "3 Nights / 4 Days",
          "category": "Hills",
          "rating": "4.5/10 Average (239 reviews)",
          "rate": 4.5
        },
        {
          "name": "Kochi",
          "info": "The city is marked by influences of Arabs, Dutch, Phoenicians, Portuguese, Chinese and the British city as well as that of the Indian rule of the Chera Dynasty followed by rule of the Feudal Lords. A gaggle of islands interconnected by ferries, this cosmopolitan town has upmarket stores, art galleries and some of the finest heritage accommodations. In a true vintage-meets-future fashion, pubs, restaurants, shopping hubs and futuristic stores crowd Ernakulum, Jew Town and Fort Kochi while palaces, beaches, temples and heritage sites marking their presence too. Kochi is also an important place to see Kathakali and Kalarippayattu performances and annual Biennale Festival.",
          "images": "https://www.holidify.com/images/bgImages/KOCHI.jpg",
          "price": 10099,
          "package": "3 Nights / 4 Days",
          "category": "Lake",
          "rating": "9.2/10 Wonderful (1,104 reviews)",
          "rate": 9.2
        },
        {
          "name": "Thekkady",
          "info": "Home to the country's largest Tiger Reserve- Periyar, Thekkady is a great way to enjoy a jungle vacation.Periyar National Park, being a major attraction, is one place where you can enjoy bamboo rafting in the catchment area of Mullaiperiyar Dam, hiking, and in the midst of the wilderness, shopping! Popular for its good eating joints, you can also enjoy its vast stretches of spice gardens and various adventure sports. You can also enjoy a night trek in the wilderness of Periyar. The early morning ride in the boat within the sanctuary is an extremely awesome experience and you might be able to spot wild elephants, bisons, wild boars, various kinds of birds, etc",
          "images": "https://static.toiimg.com/photo/56892948/.jpg",
          "price": 11000,
          "package": "3 Nights / 4 Days",
          "category": "Hills",
          "rating": "9.1/10 Wonderful (1,119 reviews)",
          "rate": 9.1
        },
        {
          "name": "Varkala",
          "info": "Varkala is a coastal town in the southern part of Kerala known for the unique 15m high 'Northern Cliff' adjacent to the Arabian Sea. It is popular for its hippie culture, shacks on the cliff serving great seafood and playing global music and the samadhi of Kerala's saint Sree Narayana Guru. Varkala is also known for Jardana Swami Temple, also known as Dakshin Kashi.Varkala has some of the best pristine beaches, hills, lakes, forts, lighthouses, natural fisheries and springs - all of this together makes this town a little paradise. ",
          "images": "https://www.varkkala.com/uploads/slides/2435199045.jpg",
          "price": 14090,
          "package": "3 Nights / 4 Days",
          "category": "Beach",
          "rating": "4.5/10 Average (1,110 reviews)",
          "rate": 4.5
        },
        {
          "name": "Poovar",
          "info": "Poovar is a small rustic town situated 27 kms from Thiruvananthapuram with unspoilt, unexplored golden sand beaches and beautiful backwaters of Kerala.Also known as a fishing village, the tranquil Poovar island lies between the Arabian Sea and the Neyyar River. Hiring a boat, (especially during the sunset)that will take you through the mangrove forest of backwaters is a must-do activity. The boat ride costs around INR 3000- INR 4000. The town has some of the beautiful resorts and hotels that are known for the hospitality they offer.",
          "images": "https://www.keralatourism.org/images/service-providers/photos/property-3322-Exterior-11040-20180831082544.jpg",
          "price": 8000,
          "package": "3 Nights / 4 Days",
          "category": "Lake",
          "rating": "8.5/10 Excellent (779 reviews)",
          "rate": 8.5
        },
        {
          "name": "Kovalam",
          "info": "Kovalam is an idyllic coastal town located around 13 km from Thiruvananthapuram in Kerala. Famous for its three adjacent crescent-shaped shallow water and low tidal beaches, Kovalam is dotted with resorts and ayurvedic massage centres.Lighthouse beach, Samudra Beach and Hawa beach/Eve's Beach form the highlight of this town. Kovalam essentially means a ‘grove of coconut trees', and the little town is filled with these palms.",
          "images": "https://www.kovalam.com/files/slides/8838110887.jpg",
          "price": 20199,
          "package": "3 Nights / 4 Days",
          "category": "Beach",
          "rating": "8.3/10 Excellent (769 reviews)",
          "rate": 8.3
        },
        {
          "name": "Kollam",
          "info": "A treasure trove of natural wonders and historical edifices, Kollam is an enchanting town with backwaters and picturesque landscapes. Located 70kms away from Thiruvananthapuram, Kerala, Kollam is a commercial centre and home to India’s cashew producing industry. Popularly known as Quilon, it is often regarded as the gateway to the backwaters of Kerala.",
          "images": "https://img.traveltriangle.com/blog/wp-content/uploads/2018/04/Jatayu%E2%80%99s-Earth-Centre-kollam-kb6592.jpg",
          "price": 4099,
          "package": "3 Nights / 4 Days",
          "category": "Hills",
          "rating": "8.1/10 Excellent (782 reviews)",
          "rate": 8.1
        },
        {
          "name": "Trivandrum",
          "info": "Offering an appealing blend of a strongly rooted heritage and a nostalgic colonial legacy, the city of Trivandrum has an exceptional vibe to it. Despite being the capital of Kerala, the city has, quite astonishingly, managed to keep itself far removed from the ruthless aura that generally surrounds a capital city. Built upon seven hills, this city has long since left the days when it was only used by seafaring explorers behind - today, Trivandrum is a swanky metropolis with a quaint urban charm and plenty of scenic places to visit. Proudly retaining its age-old cultural charm, Trivandrum offers a huge variety of sights including incredible museums, beautifully designed palaces, sacred temples and mesmerizing beaches, making the city one of the best tourist spots in South India.",
          "images": "https://images.thrillophilia.com/image/upload/s--xqlxdexK--/c_fill,f_auto,fl_strip_profile,h_775,q_auto,w_1600/v1/images/photos/000/037/624/original/trivandrum.jpg.jpg?1458192663",
          "price": 7099,
          "package": "3 Nights / 4 Days",
          "category": "Lake",
          "rating": "8.4/10 Excellent (469 reviews)",
          "rate": 8.4
        }
      ]
    },
    {
      "id": "5",
      "location": "Maharashtra",
      "capital": "Mumbai",
      "img": "https://www.tripsavvy.com/thmb/sOKirs6tks8NcKlhytwechtqOm4=/4241x2386/smart/filters:no_upscale()/GettyImages-1008831236-5c65d6bf4cedfd00014aa310.jpg",
      "place": [
        {
          "name": "Mumbai",
          "info": "Mumbai, the capital city of the Indian state of Maharashtra, is a spectacular paradox of chaos and hope, glamour and squalor, modernity and tradition. Famously known as the City of Dreams, Mumbai – formerly known as Bombay - Mumbai is a beautifully blended melting pot of cultures and lifestyles.One of the main centres in the country of art, culture, music, dance and theatre, Mumbai is a dynamic, cosmopolitan city that has been running for years solely on the indomitable spirit of the Mumbaikars.",
          "images": "https://static2.tripoto.com/media/filter/tst/img/254497/TripDocument/1460886004_cover.jpg",
          "price": 11099,
          "package": "3 Nights / 4 Days",
          "category": "Beach",
          "rating": "9.6/10 Wonderful (2,330 reviews)",
          "rate": 9.6
        },
        {
          "name": "Ajanta And Ellora Caves",
          "info": "Ajanta and Ellora caves, considered to be one of the finest examples of ancient rock-cut caves are located near Aurangabad in the state of Maharashtra, India. Adorned with beautiful sculptures, paintings and frescoes, Ajanta and Ellora caves are an amalgamation of Buddhist, Jain and Hindu monuments as the complex includes both Buddhist monasteries as well as Hindu and Jain temples. The Ajanta caves are 29 in number and were built in the period between 2nd century BC and 6th century AD whereas the Ellora Caves are more spread out and 34 in number and dates to the period between 6th and 11th Century AD.Ajanta and Ellora caves are designated as UNESCO World Heritage Sites and are quite popular among travellers from all over the world. ",
          "images": "https://static.toiimg.com/photo/52533940/.jpg",
          "price": 12099,
          "package": "4 Nights / 5 Days",
          "category": "Fort",
          "rating": "8.7/10 Excellent (919 reviews)",
          "rate": 8.7
        },
        {
          "name": "Panchgani",
          "info": "Deriving its name from the five hills surrounding it, Panchgani is a popular hill station near Mahabaleshwar, famous for its various sunset/sunrise points and scenic valley view.Located at an altitude of 1, 334 mts. , Panchgani is a hill station in Maharashtra, known for its scenic views. Five hills form the Sahyadri mountain ranges offer Panchgani its name. The picturesque backdrop of hills on one side and coastal plains on the other makes for an amazing view. In the British era, the place was treated as a summer resort and hence many colonial period establishments can be seen here. Mahabaleshwar is like a twin city to Panchgani.",
          "images": "https://images.thrillophilia.com/image/upload/s--sxUdO_kN--/c_fill,f_auto,fl_strip_profile,g_center,h_642,q_auto,w_1280/v1/images/photos/000/049/457/original/1553066319_panchgani_places_feature.jpg.jpg",
          "price": 18090,
          "package": "4 Nights / 5 Days",
          "category": "Hills",
          "rating": "7.6/10 Very Good (976 reviews)",
          "rate": 7.6
        },
        {
          "name": "Mahabaleshwar",
          "info": "Mahabaleshwar is a hill station located in the Western Ghats, in Satara district of Maharashtra. Known for its captivating beauty and the beautiful strawberry farms, the city comprises of ancient temples, boarding schools, manicured and lush green dense forest, waterfalls, hills, valleys. The city is definitely among the most sought after weekend getaways from Mumbai. Charming views, enticing valleys, serene lakes and a refreshing delight for your taste buds - the best way to summarize this natures gift.",
          "images": "https://www.holidify.com/images/bgImages/MAHABALESHWAR.jpg",
          "price": 23000,
          "package": "4 Nights / 5 Days",
          "category": "Hills",
          "rating": "7.2/10 Very Good (756 reviews)",
          "rate": 7.2
        },
        {
          "name": "Alibag",
          "info": "A little coastal town tucked away in the Konkan region of Maharashtra, Alibaug is a very popular weekend getaway holiday destination and has earned itself the name of 'mini-Goa', owing to the high tourist footfall all year round. Steeped in colonial history, Alibaug is a quaint little town located about 110 kilometres from Mumbai, and is replete with sandy beaches, clean unpolluted air and plenty of forts and temples, ensuring that despite being a small town, you never run out of activities to do.Alibaug has numerous beaches, and all the beaches are only a few minutes’ drives away from each other, so you won’t have to worry about which beach to visit and which one to leave out. The most visited in the beach in Alibaug is, of course, Alibag beach, which offers a spectacular of view of not only the sunrise and sunset but of the Colaba fort as well, which you can take a short boat ride to.",
          "images": "https://assets.architecturaldigest.in/photos/60800ec9b7b098a8ed586f33/16:9/pass/Alibag-kavita-singh.jpeg",
          "price": 8000,
          "package": "2 Nights / 3 Days",
          "category": "Beach",
          "rating": "9.2/10 Wonderful (1,109 reviews)",
          "rate": 9.2
        },
        {
          "name": "Nashik",
          "info": "Nashik (Nasik), named after a relic associated with Ramayana, is a city in Maharashtra located on the banks of river Godavari. Nashik plays host to the famous Kumbh Mela every 12 years. The city is home to plenty of exotic temples and is known in Hindu mythology as the place where Ravana's sister, Surpanakha, tried to seduce Lord Ram and got her nose cut off by Lakshman in the process. Its religious importance doesn't end there. It also plays host to the thousands of tourists visiting Shirdi and Trimbakeshwar. Apart from its temples, Nashik also has forts, waterfalls and vineyards to look out for. With multiple vineyards present in Nashik, the most popular being Sula, the wine-tourism industry is mushrooming in this part of Maharashtra. Nashik gives you the chance to experience a fabulous cocktail of extremes - from temples to vineyards, hills to waterfalls, this place offers a lot to see.",
          "images": "https://www.outlookindia.com/outlooktraveller/public/uploads/articles/explore/shutterstock_1359416978.jpg",
          "price": 15500,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "8.9/10 Excellent (2,229 reviews)",
          "rate": 8.9
        },
        {
          "name": "Kashid",
          "info": "A Beach town, popular for its white sand and blue seas situated in Konkan region of Maharashtra, Kashid is the perfect destination for a quiet weekend getaway from Mumbai.A soothing and calm place in nature's lap, Kashid is mildly enchanting with its quiet environment and picturesque location. This beach town is known also for its majestic mountains and whispering Casuarinas. A delightful place for those seeking a serene environment, Kashid is has a calm shore that stretches to a vast extent and presents with a spellbound appearance. Kashid's spotless water and clean beach makes it one of the most beautiful spots in the nearby areas. A drive through the area in itself is a great experience. Chaul, which lies near Kashid, has many Buddhist caves that are of public interest, and also famous churches and temples. The Korlai Fort is another beautiful attraction here.",
          "images": "https://images.thrillophilia.com/image/upload/s--KjcNvlyv--/c_fill,h_600,q_auto,w_975/f_auto,fl_strip_profile/v1/images/photos/000/326/563/original/1593384354_kashid-beach-tour.jpg.jpg?1593384354",
          "price": 20199,
          "package": "3 Nights / 4 Days",
          "category": "Beach",
          "rating": "9.2/10 Wonderful (1,109 reviews)",
          "rate": 9.2
        },
        {
          "name": "Aurangabad",
          "info": "Aurangabad, which was declared by the Government as the Tourism Capital of Maharashtra back in 2010, is a famous tourist hub which greets its visitors with a richly woven tapestry of sights and sounds. The city got its name for being the erstwhile capital of Mughal Emperor Aurangzeb in the 17th century AD. The town is used as the base to explore the extremely famous caves of Ajanta and Ellora, Daulatabad Fort which is renowned for its strong defence systems, Mausoleums of Aurangzeb and Bibi-Ka-Maqbara famous for its architecture and Grishneshwar Temple, one of the only 12 Shiva Jyotirlingas in India.The most famous tourist attraction of Aurangabad is the Ajanta and Ellora Caves. Declared a World Heritage Site by UNESCO, the Ajanta Caves is home to 29 different caves, all of which showcase Buddhist artwork belonging to the period ranging from 200 B.C to 650 A.D.",
          "images": "https://www.holidify.com/images/bgImages/AURANGABAD.jpg",
          "price": 18199,
          "package": "3 Nights / 4 Days",
          "category": "Fort",
          "rating": "6.5/10 Good (679 reviews)",
          "rate": 6.5
        }
      ]
    },
    {
      "id": "6",
      "location": "Uttarakhand",
      "capital": "Dehradun",
      "img": "https://images.thrillophilia.com/image/upload/s--RZhmz_7S--/c_fill,f_auto,fl_strip_profile,h_775,q_auto,w_1600/v1/images/photos/000/082/491/original/1464188297_I2GZl5w7lL-1920x1080.jpg.jpg?1464188297",
      "place": [
        {
          "name": "Rishikesh",
          "info": "Located in the foothills of the Himalayas along the convergence of Ganga and Chandrabhaga River, Rishikesh (also called as Hrishikesh) is known for its adventure activities, ancient temples, popular cafes and as the \"Yoga Capital of the World\". With whitewater rafting industry growing and varied camping and cafe spots springing up, Rishikesh has grown immensely as a favourite, catering to people with different needs.Over the years, the tranquil town has become extremely popular as the top spiritual destination in the world, especially after the Beatles association with Maharishi Mahesh Yogi here in the late '60s. As it lies on the holy banks of river Ganga, Rishikesh has been a hub of Sadhus (saints) with numerous ashrams teaching spirituality, yoga, meditation and Ayurveda springing up, the most popular of which is the Beatles Ashram.",
          "images": "https://images.thrillophilia.com/image/upload/s--n6G46YVa--/c_fill,g_auto,h_600,q_auto,w_975/f_auto,fl_strip_profile/v1/images/photos/000/013/585/original/1594791200_shutterstock_1137990866.jpg.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "9.2/10 Wonderful (1,209 reviews)",
          "rate": 9.2
        },
        {
          "name": "Nainital",
          "info": "The gem of Uttarakhand - Nainital is a charming hill station that sits prettily at the green foothills of the Kumaon ranges in the Himalayas. Located at an elevation of around 1938 metres, the epicentre of the town’s popularity and beauty lies within the gorgeous Naini Lake, after which the town is named. Founded by the British due to its resemblance to the Cumbrian Lake district, Nainital brims with elegant colonial structures that amplify the beauty of this place. It is a perfect weekend getaway from the Indian capital of Delhi.This quaint little town experiences a pleasant climate throughout the year, making it a tourist getaway, especially preferred by families and honeymooners. The Naini Lake, along with the other lakes in the area, has earned this town the title of ‘City of Lakes’. Whether you want to go boating on the beautiful Naini Lake or any of the other lakes, relish some local delicacies, shop at the Tibetan Market and Mall Road, or take a ropeway ride to soak in the beauty of the Himalayas from Snow View Point, Nainital is sure to leave an imprint on you that will last a lifetime.",
          "images": "https://www.holidify.com/images/bgImages/NAINITAL.jpg",
          "price": 10500,
          "package": "4 Nights / 5 Days",
          "category": "Hills",
          "rating": "6.5/10 Good (449 reviews)",
          "rate": 6.5
        },
        {
          "name": "Mussorie",
          "info": "If your idea of the perfect holiday involves tranquil hills, untouched nature and a holiday experience that is unadulterated in the truest sense of the term, Mussoorie is the place you should be heading to. Nestled amidst the foothills of the Garhwal Himalayan ranges, Mussoorie, also known as Queen of The Hills, stands at an altitude of 7000 feet above sea level, and has a cool, pleasant climate throughout the year. The pristine, natural beauty of Mussoorie makes it a very popular choice of holiday for honeymooners. If you want to enjoy the beautiful sight of the rolling green slopes juxtaposed with the snow-capped peaks of the Himalayas, Mussoorie is the place for you to be.This beautiful hill station is the perfect retreat from the sweltering weather of the plains, and the fact that it was a very popular holiday destination during the British era can be seen from the multitude of British remnants engulfing the city, such as the archaic architecture of the hotels and churches dotting the entire terrain.",
          "images": "https://www.holidify.com/images/bgImages/MUSSOORIE.jpg",
          "price": 16500,
          "package": "4 Nights / 5 Days",
          "category": "Hills",
          "rating": "4.3/10 Average (1,009 reviews)",
          "rate": 4.3
        },
        {
          "name": "Badrinath",
          "info": "Perched on the Garhwal hill tracks, near Alaknanda River, the most sacred Badrinath Temple or the Badrinarayan Temple is dedicated to Lord Vishnu. The temple is also one of the four Char Dham and Chota Char Dham pilgrimage yatras.  Situated at the height of 10,279 feet, the temple is surrounded by lofty snow-clad Himalayas. Believed to be originally established by the saint, Adi Shankaracharya, the black stone idol of Lord Vishnu is 1m tall and is considered to be one of the 8 swayam vyakta kshetras or self-manifested statues of Vishnu. It also finds its mention in the 108 Divya Desams devoted to Lord Vishnu in India.The religious importance and purity of Badrinath Temple allures scores of devotees.Badrinath Temple has a Tapt Kund, a hot water spring which is considered to have medicinal values. River Alaknanda is known to originate from here. The vibrant festivals of Mata Murti Ka Mela and the Badri Kedar Festival give you another reason to visit the temple.",
          "images": "https://res.cloudinary.com/thrillophilia/image/upload/c_fill,f_auto,fl_progressive.strip_profile,g_auto,h_600,q_auto,w_auto/v1/filestore/i4715cmnpd467ym1giq47l45euyv_1591255352_shutterstock_1435110059.jpg",
          "price": 13250,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "9.2/10 Wonderful (1,222 reviews)",
          "rate": 9.2
        },
        {
          "name": "Haridwar",
          "info": "Haridwar, considered to be among the seven holiest cities in India, is an ancient city located on the banks of River Ganga in the Garhwal region of Uttarakhand. Dotted with temples, ashrams and narrow lanes across the city, Haridwar is a famous Hindu temple town where millions of devotees come to take a dip in the holy Ganges. It's believed that taking a dip in the holy Har Ki Pauri relieves you of all your sins.Every evening, Haridwar is witness to a set of rituals for the famous Ganga Aarti at the Ghats (River Banks) where thousands of devotees come together to pray to the river. Once in every twelve years, Haridwar is host to the mega-gathering during the world famous Kumbh Mela which sees millions of visitors from all over the country.",
          "images": "https://www.holidify.com/images/bgImages/HARIDWAR.jpg",
          "price": 15500,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "9.6/10 Wonderful (2,009 reviews)",
          "rate": 9.6
        },
        {
          "name": "Kedarnath",
          "info": "Kedarnath is one of the most sacred Hindu temples as it is a part of Chhota Char Dham Yatra in Uttarakhand. The temple is the highest among the 12 Jyotirlingas dedicated to Lord Shiva. This abode of Lord Shiva can only be reached from Gaurikund through a trek and remains closed for the six months of winters due to heavy snowfall. Kedar is another name of Lord Shiva, the protector, and the destroyer, and its believed that a journey to this sacred land opens up doorways to \"Moksha\" or salvation.Located on the Garhwal Himalayan Range in the Rudraprayag District, the Kedarnath Temple is situated at the height of 3,583 metres. Set amidst the snow-clad mountains near Chorabari Glacier with Mandakini River flowing in front of it, Kedarnath witnesses lakhs of devotees every year due to its religious significance. ",
          "images": "https://imgnew.outlookindia.com/public/uploads/articles/2021/3/11/kedarnath_20201113.jpg",
          "price": 18500,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "9.9/10 Wonderful (3,711 reviews)",
          "rate": 9.9
        },
        {
          "name": "Auli",
          "info": "Dotted with the apple orchards, old oaks and pine trees there is no dearth of natural beauty in Auli. Apart from skiing you can also go for numerous treks in the hills of Garhwal Himalayas and enjoy the spellbinding views of the snow-draped mountains. Auli is a popular hill resort in the Himalayan range dating back to 8th Century AD.Auli is a popular skiing destination in India because of its glittering slopes and clean environment. Dotted with apple orchards, oaks and deodars, Auli is a popular hill town with numerous ski resorts situated amidst the Himalayan range. Located at 2800 meters above sea levels, it is home to mountain ranges of Nanda Devi, Mana Parvat and Kamat Kamet. Many religious destinations are also scattered around Auli. It is believed that Shankracharya had blessed Auli with his visit.",
          "images": "https://www.holidify.com/images/cmsuploads/compressed/sdfsdsdgsdgsdg_20181211083314.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain snowfall",
          "rating": "4.2/10 Average (209 reviews)",
          "rate": 4.2
        },
        {
          "name": "Dehradun",
          "info": "Nestled amidst the Doon Valley in the state of Uttarakhand, Dehradun is a very popular hill station that beckons solo travellers, families and couples alike. Proudly boasting of a scenic backdrop of the Garhwal Himalayas, Dehradun is located at an altitude of 1400 feet above sea level and has a pleasant climate all year round. Regardless of whether you want to explore family-friendly tourist spots, try thrilling adventure activities with your friends, or watch a mesmerizing sunset with your partner amidst the mountains, Dehradun is the answer.As you would expect from a city located in the foothills of the Himalayas, Dehradun abounds in caves, waterfalls and natural springs. One such extremely popular spot is Robber's Cave, which is a natural cave surrounded by hills.",
          "images": "https://www.holidify.com/images/bgImages/DEHRADUN.jpg",
          "price": 12500,
          "package": "3 Nights / 4 Days",
          "category": "Hills",
          "rating": "5.5/10 Average (229 reviews)",
          "rate": 5.5
        },
        {
          "name": "Almora",
          "info": "Famous for its rich cultural heritage, unique handicrafts, sumptuous cuisine and magnificent wildlife, coupled with an easy accessibility, Almora promises its tourists a visit full of fun and unforgettable moments. This agrarian town has two major rivers- Koshi (Kaushaki) and Suyal (Salmali) flowing through it. \"The enchanting beauties of the Himalayas, their bracing climate and the soothing green that envelopes you leaves nothing more to be desired. I wonder whether the scenery of these hills and the climate are to be surpassed, if equaled, by any of the beauty spots of the world. After having been nearly three weeks in Almora Hills, I am more than ever amazed why our people need go in Europe in search of health. \" - Mahatma Gandhi",
          "images": "https://www.holidify.com/images/bgImages/ALMORA.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain",
          "rating": "3.5/10 Average (109 reviews)",
          "rate": 3.5
        },
        {
          "name": "Dhanaulti",
          "info": "With minimal human intrusion, without overloading or overwhelming your senses or expectations, Dhanaulti slowly seeps into your conscience like a long lost pleasant dream, bringing with it comfort and quiet, and giving you the much needed break from your humdrum routine life.Located at a distance of 62 km from Mussoorie, this little town in Uttarakhand is an offbeat destination located at a height of about 2200 meters above sea level.",
          "images": "https://www.holidify.com/images/foreign/compressed/attr_123716.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Hills",
          "rating": "3.2/10 Average (229 reviews)",
          "rate": 3.2
        },
        {
          "name": "Ranikhet",
          "info": "Ranikhet meaning Queen's farm, is a hill station developed by the Britishers around ancient temples, undulating Himalayan hills and forests.Ranikhet with its cool climate and simple natural beauty can freshen up your senses to the very core. It is also popular as the Headquarters of the Kumaon Regiment of the Indian Army and has the Kumaon Regimental Centre Museum. The museum has a splendid display of weapons, photo etc. to introduce you the grandness and significance of military and its various historical instances. Ranikhet is popular for its views of the Nanda Devi Peak, trekking ranges, mountainous climbs, golf courses, orchards and temples.",
          "images": "https://www.tourmyindia.com/blog//wp-content/uploads/2016/02/Visiting-Ranikhet.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Hills",
          "rating": "4.0/10 Wonderful (299 reviews)",
          "rate": 4
        }
      ]
    },
    {
      "id": "7",
      "location": "Himachal Pradesh",
      "capital": "Shimla",
      "img": "https://assets-news.housing.com/news/wp-content/uploads/2022/07/18131039/shimla-feature-compressed.jpg",
      "place": [
        {
          "name": "Manali",
          "info": "Nestled in between the snow-capped slopes of the Pir Panjal and the Dhauladhar ranges, Manali is one of the most popular hill stations in the country. With jaw-dropping views, lush green forests, sprawling meadows carpeted with flowers, gushing blue streams, a perpetual fairy-tale like mist lingering in the air, and a persistent fragrance of pines and freshness -  Manali has been blessed with extraordinary scenic beauty. From museums to temples, from quaint little hippie villages to bustling upscale streets, river adventures to trekking trails, Manali has every reason to be the tourist magnet it is, all year round.Clean roads, swaying eucalyptus trees, endearing little eateries, small kitschy local market places, and cafes which serve delicious local food at unbelievable prices, Old Manali is a serene, tranquil place, whose lingering silence is broken only by the twittering of the birds and the sound of the roaring waters of the Kullu river.",
          "images": "https://www.holidify.com/images/bgImages/MANALI.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain Climbing",
          "rating": "9.2/10 Wonderful (1,309 reviews)",
          "rate": 9.2
        },
        {
          "name": "Shimla",
          "info": "Situated at a height of 2200m, Shimla is the capital and the largest city of Himachal Pradesh in India. Set amidst beautiful hills and mystical woods, Shimla has been a very popular hill-station among Indian families and honeymooners since the last 50 years.\n\nBritish loved this city so much that they made Shimla their summer capital in 1864 and used to rule the sub-continent from here whenever the temperature rose in the nearby plains. Shimla still retains its old world charm with beautiful colonial architecture, pedestrian-friendly Mall Road and beautiful churches.",
          "images": "https://www.holidify.com/images/bgImages/SHIMLA.jpg",
          "price": 17500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain Climbing",
          "rating": "9.6/10 Wonderful (1,009 reviews)",
          "rate": 9.6
        },
        {
          "name": "Mcleodganj",
          "info": "Mcleodganj is a hill station near Dharamshala, popular among trekkers. Its culture is a beautiful blend of Tibetan with some British influence.Also known as Little Lhasa and famous around the world for being home to the Tibetan spiritual leader Dalai Lama, Mcleod Ganj is a beautiful town situated near upper Dharamsala. Nestled amidst majestic hills and lush greenery, this town is culturally blessed by a prominent Tibetan influence owing to the major settlement of Tibetans here. Mcleodganj has one of the most mesmerising landscapes in the entire state of Himachal Pradesh and attracts a lot of tourists throughout the year. The towns of Dharamsala, Mcleodganj, Bhagsu Nag and Kangra are situated very close to each other and tourists must cover all these destinations while travelling here. Few of the most eminent and religiously significant monasteries in India are located here, including the Namgyal Monastery and Tsuglagkhang, where the spiritual leader Dalai Lama resides. Tourists must also visit the scenic Dal Lake and Triund, which are apt for quiet picnics.",
          "images": "https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/McLeod_Ganj_Dharamkot_Dharmsala_Himachal_Pradesh_India_April_2014.jpg/417px-McLeod_Ganj_Dharamkot_Dharmsala_Himachal_Pradesh_India_April_2014.jpg",
          "price": 23500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain Climbing",
          "rating": "3.3/10 Average (219 reviews)",
          "rate": 3.3
        },
        {
          "name": "Dalhousie",
          "info": "The tiny tinsel town Dalhousie tucked away in the lap of Himachal Pradesh is a piece of paradise for all the travellers. It boasts of old world charm, mesmerising natural landscape, pine-clad valleys, flower bedecked meadows, fast flowing rivers, magnificent misty mountains and some of the most spectacular views in the world. The air smells of the Scottish and Victorian architecture and the ambience reminds you of the pristine British flavours.Dalhousie, one of the favourite among most tourists travelling to Himanchal Pradesh is famously known for its mesmerizing natural beauty and its old world charm. This hill station was one of the most favourite summer destinations of the ruling Britishers and this is truly reflected in the majestic Victorian style mansions in this region. Situated far from the buzzing cities in the country, this quaint town transports you to a pollution-free environment in the lap of nature. Dalhousie is known for its scenic beauty has a number mountains and river streams that tourists must visit. Among them the most famous are Panch Pulla, Satdhara Falls and the Daikund peak.",
          "images": "https://www.tourmyindia.com/states/himachal/images/beauty-of-himachal.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain",
          "rating": "4.6/10 Average (339 reviews)",
          "rate": 4.6
        },
        {
          "name": "Spiti Valley",
          "info": "Long winding roads and valleys that present unforgettable glimpses of cold desert and snow-crowned mountains welcome you when you set foot into Spiti Valley. Bordered on all sides by the Himalayas, Spiti Valley, located in Himachal Pradesh, has an altitude of 12,500 feet above sea level, and gets just around 250 days of sunshine in the year, making it one of the coldest places in the country. With the thick Himalayan snow cutting Spiti off from the rest of the country for around 6 months a year, the summer months are the only time Spiti is directly accessible via motorway.The term Spiti means 'The Middle Land', as Spiti Valley separates India from Tibet. Scantily populated, Spiti is an adventure lover’s paradise, with a number of trekking trails that tourists can choose from. All of these treks start from Kaza (Spiti’s capital from where you make your base camp) to various peaks from where you can get panoramic views of the Himalayan mountains. An easy 1.5-kilometre trek along the Spiti River from Dhankar Monastery to Dhankar Lake promises gorgeous views of the villages below. The Dhankar Lake itself is a place where you can sit back and relax amidst the cool mountain air.",
          "images": "https://www.holidify.com/images/bgImages/SPITI.jpg",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain",
          "rating": "9.2/10 Wonderful (1,119 reviews)",
          "rate": 9.2
        },
        {
          "name": "Kasol",
          "info": "A small village in Himachal situated along the banks of the river Parvati, Kasol is a tourist attraction that is rapidly gaining fame as a very popular hub for trekkers, backpackers, and nature lovers. Commonly known as the Amsterdam of India, this quaint little village is resplendent in natural scenic beauty, and is one of the few places in the country that is yet to be ruined by urbanization and commercialization. Situated between the towns of Bhuntar and Manikaran, Kasol might seem like a plain, nondescript village from the outside, but it is one of the best places in the country to just sit back and chill in the lap of nature.With the waters of the Parvati river gurgling along and a stunning view of the snow-capped mountains in the background, taking a stroll along the river is one of the best ways to spend a day in Kasol. With smooth boulders and clean white sand separating the green grass from the frothing sea-green waters of the river, every single bend in the river opens up to a breathtaking panorama of cliffs, pine trees, and gushing waterfalls.",
          "images": "https://hblimg.mmtcdn.com/content/hubble/img/new_dest_imagemar/mmt/activities/m_Kasol_3_l_800_1200.jpg",
          "price": 22500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain",
          "rating": "4.3/10 Average (422 reviews)",
          "rate": 4.3
        },
        {
          "name": "Dharamshala",
          "info": "Dharamsala is famed as the holy residence of the Dalai Lama and houses the Tibetan monk in exile. Dharamsala is located in Kangra district at a distance of 18km from Kangra City. The city is distinctively separated as upper and lower divisions with different altitudes. The lower division is the Dharamsala town itself whereas the upper division is popularly known as Mcleodganj.This is situated on the upper hilly stretch of land of Kangra Valley which is placed just against the picturesque scene of Dhauladhar ranges. Being a Tibetan hub, Dharamsala is considered to be one of the best places to learn and explore Buddhism and Tibetan Culture.",
          "images": "https://img.veenaworld.com/wp-content/uploads/2018/06/travel-dglobe.jpg?imwidth=1080",
          "price": 14500,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "7.7/10 Very Good (889 reviews)",
          "rate": 7.7
        },
        {
          "name": "Kinnaur",
          "info": "Kinnaur, also known as \"Land of God\" is about 235 Km from Shimla and is known for its serenity and beauty of the lush green and rocky mountainscape having Satluj, Baspa and Spiti river meandering through it. A brotherly fusion of Hinduism and Buddhism at one place reflects the existence of a culture of a different sort which is well preserved by its people in this era of modernization. Hindus visit Kinnaur to see the famous Kinner Kailash, believed to be the home of Lord Shiva and the Shivaling rocks, the stories of Pandavas and their link with Kinnaur is a great attraction.There are also old Buddhist monasteries and temples in the vicinity which hold special importance and are revered by Buddhists. Apart from religion, Kinnaur also has a vast scope in adventure sports like trekking and skiing. There are about nine known routes for trekking and some which are five days or six-day trips",
          "images": "https://images.thrillophilia.com/image/upload/s--GtWQwh90--/c_fill,g_auto,h_600,q_auto,w_975/f_auto,fl_strip_profile/v1/images/photos/000/142/609/original/1548921352_kinnaaaaur.jpg.jpg",
          "price": 20000,
          "package": "4 Nights / 5 Days",
          "category": "Mountain",
          "rating": "6.8/10 Good (456 reviews)",
          "rate": 6.8
        },
        {
          "name": "Kufri",
          "info": "Kufri in Shimla district, Himachal Pradesh is one of the most sought after holiday destinations, and more so for couples, because of its proximity to Shimla and relatively higher altitude which makes it a place with snow all through the winters.Kufri is just about 10 km from Shimla and is quite a retreat if you're in Shimla and snow is something which excites you. While there's not much to see in Kufri as such, but the panoramic views and temples after a bit of trekking are worth the time. Kufri itself is mostly treated as a spot for the tourists visiting Shimla and it is advisable to club sightseeing in Shimla or nearby areas like Chail, Mashobra, Naldehra or Narkanda as well if you intend to visit Kufri. Also, Kufri is a relatively crowded and popular attraction as almost everyone visiting Shimla comes here.",
          "images": "https://static.india.com/wp-content/uploads/2022/02/pjimage-2022-02-21T125513.893.jpg",
          "price": 18500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain snowfall",
          "rating": "5.8/10 Average (779 reviews)",
          "rate": 5.8
        },
        {
          "name": "Chamba",
          "info": "Chamba is a Himalayan town located in Chamba district of Himachal Pradesh. Known for the ancient temples, the caves, and the edifices that speak highly of Indian history, Chamba is famous for the gob-smacking views of the Pir Panjal, Zanskar and Dhauladhar ranges set in the backdrop of a picture-postcard town. This epitome of the Himalayan town is located at an elevation of 996 meters on the banks of river Ravi flanked by Jammu and Kashmir, Lahaul and Kangra.Chamba is popular for its traditional handicrafts and art along with the miniature Pahari paintings - a form of Indian painting that originated from the Himalayan hill kingdoms of North India during the 17th to 19th centuries. It is also the base camp for several treks in the great Himalayan ranges. This, along with the stunning beauty and tranquil environs beckons travellers looking for an offbeat location among the much-popular Himachali towns.",
          "images": "https://www.adotrip.com/public/images/city/5c3db76cc2a50-Chamba%20Package%20Tour.jpg",
          "price": 28000,
          "package": "4 Nights / 5 Days",
          "category": "Lake",
          "rating": "9.2/10 Wonderful (1,009 reviews)",
          "rate": 9.2
        },
        {
          "name": "Kheerganga Trek",
          "info": "Kheer Ganga (3050 meters) lies at the extreme end of Parvati valley and the last inhibited village while trekking to pin valley via Pin-Parvati pass. Kheerganga's panoramic skies and vast greenery are a much-needed delight to the trekker's eyes and especially the tired legs. It is a holy place with a hot water spring, a small temple of Lord Shiva and a bathing tank. It makes a rare combination for any trekker to bath in hot spring water when everything is covered by snow.",
          "images": "https://www.lazymonkadventure.com/wp-content/uploads/2021/10/Kasol-Kheerganga-Trek-3-scaled.jpg",
          "price": 29500,
          "package": "4 Nights / 5 Days",
          "category": "Mountain Climbing",
          "rating": "7.3/10 Very Good (609 reviews)",
          "rate": 7.3
        }
      ]
    },
    {
      "id": "8",
      "location": "Gujarat",
      "capital": "Gandhinagar",
      "img": "https://cdn.dnaindia.com/sites/default/files/styles/full/public/2018/11/12/753361-statueofunity-reuters-110118.jpg",
      "place": [
        {
          "name": "Ahmedabad",
          "info": "A rapidly growing metropolis, an industrial hub, an educational hotspot, and a city with a magnificent past – Ahmedabad is one of the most important cities in Gujarat. Located on the banks of the Sabarmati River, Ahmedabad is the former capital of Gujarat, and its delicious food, colourful culture is making it a fast-growing tourist destination. The historic city of Ahmedabad or the old part of the city was declared as the UNESCO World Heritage Site.Home to a plethora of remarkable temples like Swaminarayan Temple, intriguing museums and classy markets, with a little bit of colonial history attached to it, Ahmedabad is an excellent example of how a city can still retain every bit of its old-world charm while still rapidly progressing on the path of globalisation.",
          "images": "https://en-media.thebetterindia.com/uploads/2022/08/Untitled-design-2022-08-27T121008.682-1661584220.jpg?compress=true&quality=80&w=400&dpr=2.6",
          "price": 9500,
          "package": "2 Nights / 3 Days",
          "category": "Lake",
          "rating": "8.2/10 Excellent (989 reviews)",
          "rate": 8.2
        },
        {
          "name": "Kutch",
          "info": "Virtually an island that resembles the shape of a tortoise, Kutch is an erstwhile princely state of India holding onto its grandeur nature from the past.Kutch is probably one of the most beautiful, yet surreal places in India. With the vast expanses of white salt desert in the Rann of Kutch area, this is an amazing experience to witness. One would be able to see just stretches of pure white land as far as the eyesight goes. The place comes to life during the winters when the Rann Festival is held during December-February everywhere in which there are huge camp settlements with cultural programs, functions and adventure activities like hot-air ballooning. Kutch is also among the largest district of India with a terribly low population density.",
          "images": "https://utsav.gov.in/public/uploads/event_cover_image/event_13/1649078511645355156.jpg",
          "price": 8000,
          "package": "3 Nights / 4 Days",
          "category": "Desert",
          "rating": "9.2/10 Wonderful (1,009 reviews)",
          "rate": 9.2
        },
        {
          "name": "Somnath",
          "info": "Somnath, literally meaning 'lord of the moon' is a pilgrim center and is home to one of the 12 Jyotirlingas. It is a town which derives much of its identity from the mythology, religion, and legends that surround it.Primarily a temple town, Somnath is a place where a strong scent of religion and legends lingers around tourism and even daily life. Its spiritual environment is ornamented by the huge number of temples in the area, however, Somnath also offers beaches, museums and other attractions. While the Somnath temple and Somnath beach are the primary places to visit here, Gita Mandir, Balukha Tirtha, Kamnath Mahadev Temple, Somnath Museum are some of the other places that one can visit.",
          "images": "https://www.holidify.com/images/bgImages/SOMNATH.jpg",
          "price": 23000,
          "package": "2 Nights / 3 Days",
          "category": "Temple",
          "rating": "9.8/10 Wonderful (3,009 reviews)",
          "rate": 9.8
        },
        {
          "name": "Vadodara",
          "info": "Vadodara or Baroda is a cosmopolitan city located in Gujarat. Home to some of the most exemplary displays of architecture, Vadodara is a fitting memorial to Maratha leader Sayaji Rao Gaekwad III who had envisioned a dream to make this Big City an educational, industrial and commercial centre.Known for one of the most lavish palaces in India- the Lakshmi Vilas Palace and plenty more legendary monuments, Vadodara is the cultural capital of Gujarat. ",
          "images": "https://media-cdn.tripadvisor.com/media/photo-c/2560x500/0d/41/e6/b1/laxmi-vilas-palace.jpg",
          "price": 5500,
          "package": "2 Nights / 3 Days",
          "category": "Fort",
          "rating": "7.2/10 Very Good (716 reviews)",
          "rate": 7.2
        },
        {
          "name": "Diu",
          "info": "Located near the port of Veraval, Diu is a small island which was earlier a Portuguese colony, and is now guarded by beaches all around.The Diu Fort, a primary imprint of the Portuguese on the area's heritage and architecture makes up a popular tourist attraction. Another interesting place is the Vanakbara, a small fishing village whose charm has tints of colourful fishing boats and humming of day to day activity. This perfect add-on to a visit to Gujarat will complete your experience with interesting museums such as the Sea Shell Museum, temples and churches.",
          "images": "https://dseventsco.in/wp-content/uploads/2019/07/daman-diu.jpg",
          "price": 16500,
          "package": "4 Nights / 5 Days",
          "category": "Beach",
          "rating": "9.2/10 Wonderful (1,809 reviews)",
          "rate": 9.2
        },
        {
          "name": "Bhuj",
          "info": "A desert city with long history of kings and empires make Bhuj one of the most interesting and unique historical places to see.The city has a long history of kings and empires - and hence many historic places to see. The city was left in a state of devastation after the 2001 earthquake and is still in the recovery phase. Bhuj connects you to a range of civilizations and important events in South Asian history through prehistoric archaeological finds, remnants of the Indus Valley Civilization (Harappan), places associated with the Mahabharata and Alexander the Great's march into India and tombs, palaces and other buildings from the rule of the Naga chiefs, the Jadeja Rajputs, the Gujarat Sultans and the British Raj. ",
          "images": "https://magarticles.magzter.com/articles/10916/256481/5a311b1033e14/Dadra-And-Nagar-Haveli.jpg",
          "price": 2500,
          "package": "1 Nights / 2 Days",
          "category": "Temple",
          "rating": "6.5/10 Good (569 reviews)",
          "rate": 6.5
        },
        {
          "name": "Surat",
          "info": "Surat, having its name associated with Saurashtra (the good land), is a port city in Gujarat. The second most populated city in the state, Surat is a global diamond cutting centre and a commercial hub of textiles. Known as 'the city of flyovers', it attracts tourists who are interested in the colonial history of the region and the exotic wildlife.Packed on the south bank of a sharp bend in the Tapi River (Tapti), Surat is located 306 km south of the state capital, Gandhinagar. Once known for silk-weaving, it emerged as a major textile and diamond hub of India, with the shops in the New Textile Market area often crowded with buyers and shoppers. Prominent tourist attractions in Surat are the Surat Castle, Science Centre Complex and the Diamond Gallery among others.",
          "images": "https://hblimg.mmtcdn.com/content/hubble/img/surat/mmt/activities/m_activities_surat_ubharat_umbharat_beach_l_360_640.jpg",
          "price": 8900,
          "package": "2 Nights / 3 Days",
          "category": "Beach",
          "rating": "8.2/10 Excellent (989 reviews)",
          "rate": 8.2
        }
      ]
    },
    {   
      "id": "9",
      "location": "Karntaka",
      "capital": "Bengaluru",
      "img": "https://trendaroundus.in/wp-content/uploads/2022/01/Famous-Historical-Places-in-Karnataka-800x425.jpg",
      "place": [
        {
          "name": "Hampi",
          "info": "Hampi is one of the most famous historical places in Karnataka under UNESCO. The city is known for its ancient temples and monuments that date back to a thousand years. It has been an important seat in the history of Karnataka and has around 500 ancient temples; archaeological monuments; treasury building; bastions. What makes this place a famous backpacker’s delight is its hippie vibe along with vibrant street markets abound with handcrafts and souvenirs. Virupaksha Temple and Vithala Temple are the most famous historical places in Hampi. To explore the major historical monuments of Karnataka, make sure to visit this fascinating city.",
          "images": "https://trendaroundus.in/wp-content/uploads/2022/01/Famous-Historical-Places-in-Karnataka-800x425.jpg",
          "price": 7500,
          "package": "2 Nights / 3 Days",
          "category": "Historical",
          "rating": "8.2/10 Excellent (989 reviews)",
          "rate": 9.1
        },
        {
          "name": "Mysore",
          "info": "Mysore has been one of the most iconic places in the history of Karnataka as it used to be the home for the Wodeyar rulers for seven centuries. It is visited by more than 2.5 million tourists every year. That's not all. Mysore has myriad attractions for you to explore like Lalitha Mahal, Jagmohan Palace, Brindavan Gardens, and Mysore Zoo. You could also go shopping in the city and buy famous souvenirs like Khadi cotton, incense sticks, sandalwood products, etc. Do not forget to try the world-famous Mysore Pak on your visit.",
          "images": "https://assets.traveltriangle.com/blog/wp-content/uploads/2019/09/Mysore.jpeg",
          "price": 10000,
          "package": "3 Nights / 4 Days",
          "category": "Historical",
          "rating": "9.2/10 Wonderful (1,009 reviews)",
          "rate": 9.2
        },
        {
          "name": "Munnar",
          "info": "Distinguished by the carpets of rolling tea pastures and endless greenery, Munnar is among the most beautiful hill stations near Karnataka. The serene ambiance, pleasant weather, winding roads, tea and spice plantations, and those misty views lure in scores of travelers here every year. Located on the Kannan Devan hills in Kerala district, this hill town sits proudly on the Western Ghats 1,700 m above sea level and is one of the prominent tea providers in India. Though there are various other hill stations in and around Karnataka, this one surely tops the list owing to its unmatched beauty and picture-perfect landscapes.",
          "images": "https://img.traveltriangle.com/blog/wp-content/uploads/2019/11/Munnar-In-December-cover_22nd-Nov.jpg",
          "price": 23000,
          "package": "2 Nights / 3 Days",
          "category": "Hill",
          "rating": "9.8/10 Wonderful (3,009 reviews)",
          "rate": 9.8
        },
        {
          "name": "Murudeshwar Temple",
          "info": "Murudeshwar temple is a top tourist location as it has the world’s second tallest statue of Shiva standing high at 123 feet above sea level. It is one of the best places to visit in Murudeshwar. Located on the hill of Kanduka Giri, the temple is surrounded by the sea on all three sides and its lofty statue is a great site to view. The temple is also famously known as the Kethappa Narayana temple and has a 20-storey tall gopuram, which is a gatehouse tower. Pilgrims flock from all over the country for a view of this alluring sculpture.",
          "images": "https://img.traveltriangle.com/blog/wp-content/uploads/2018/07/cover-image-places-to-visit-in-murudeshwar.jpg",
          "price": 5500,
          "package": "2 Nights / 3 Days",
          "category": "Temple",
          "rating": "7.2/10 Very Good (716 reviews)",
          "rate": 7.2
        },
        {
          "name": "Mallikarjuna Temple",
          "info": "Pattadakal is a UNESCO World Heritage Site and belongs to the 7th and 8th centuries. This site is home to famous Hindu and Jain temples that are of great importance to people who believe in Hinduism and Jainism. Mallikarjuna Temple is one of these ancient temples and is located at the mesmerizing site of Pattadakal. This temple is also known as Trailokeshwara Maha Saila Prasada and was built in the 8th century. Lord Shiva is the main deity of this temple and a lot of Hindu pilgrims visit it all year round.",
          "images": "https://images.fineartamerica.com/images/artworkimages/mediumlarge/3/mallikarjuna-temple-kasivisvesvara-temple-pattadakal-sharvari-mehendale.jpg",
          "price": 16500,
          "package": "4 Nights / 5 Days",
          "category": "Temple",
          "rating": "9.2/10 Wonderful (1,809 reviews)",
          "rate": 9.2
        },
        {
          "name": "Ooty",
          "info": "The true gem of the Nilgiris, or the 'Blue Mountains' as they're sometimes called, Ooty is among the most beautiful hill stations in the country owing to its boundless beauty. Misty hills, aromatic tea plantations, alluring forest ranges, and a super pleasing climate year-round, Ooty has everything you need to make your getaway to the hills a memorable one!",
          "images": "https://assets.traveltriangle.com/blog/wp-content/uploads/2015/10/ooty-2.jpg",
          "price": 4500,
          "package": "1 Nights / 2 Days",
          "category": "Hill",
          "rating": "6.5/10 Good (569 reviews)",
          "rate": 6.5
        }
      ]
    },
    {
      "id": "10",
      "location": "Madhya Pradesh",
      "capital": "Bhopal",
      "img": "https://www.optimatravels.com/madhya-Pradesh/madhya-pradesh-india.aspx",
      "place": [
        {
          "name": "Pachmarhi",
          "info": "Famed as the Queen of the Satpuras, Pachmari Hill in the Hoshangabad district of Madhya Pradesh is truly a refreshing retreat for holidayers. The place allures visitors with the ancient caves, known as the Pandavas Caves. Along with the Priyadarshini waterfall and Apsara Vihar, the hill station is ideal to capture unbelievable colours of the sky during dusk and dawn. Rajendragiri sunset point is a great choice if you wish to click some stunning postcard kind of photographs.",
          "images": "https://img.traveltriangle.com/blog/wp-content/uploads/2023/07/Pachmarhi.jpg",
          "price": 7500,
          "package": "2 Nights / 3 Days",
          "category": "Hill",
          "rating": "8.2/10 Excellent (989 reviews)",
          "rate": 9.1
        },
        {
          "name": "Omkareshwar Temple",
          "info": "Being one of the 12 Jyotirlingas shrines of Shiva, Omkareshwar is an abode of divine spirituality for pilgrims who visit it every year in numerous numbers. It is quite fascinating that the place is naturally shaped like ‘Om’- the most auspicious symbol of Hinduism. The hanging bridge over the Narmada makes it even more amazing and captivating which is why there is no doubt that people get overwhelmed seeing its scenic beauty and divinity.",
          "images": "https://thebongexplorers.files.wordpress.com/2021/03/01-omkareshwar-1.jpg",
          "price": 11500,
          "package": "3 Nights / 4 Days",
          "category": "Temple",
          "rating": "9.2/10 Wonderful (1,009 reviews)",
          "rate": 9.2
        },
        {
          "name": "Kandariya Mahadev Temple",
          "info": "Built around 1025-1050 AD, this temple exudes grandeur and finesse in its architecture. With beautiful frescos of women in various postures adorning the walls of this temple, this place is one of the most stunning tourists sites in Khajuraho. Kandariya Mahadev Temple has an artistically engraved shrine with over 800 images of women, most of which are more than 3 feet high. The temple is dedicated to Lord Shiva and has a shivalingam at the centre of Garba Griha. Made of a typical sandstone structure, the artisitic representation of eroticism on the walls of this temple are bound to give a new perspective on India's cultural heritage.",
          "images": "https://www.holidify.com/images/cmsuploads/compressed/shutterstock_1555433651_20200219145507_20200220101052.png",
          "price": 23000,
          "package": "2 Nights / 3 Days",
          "category": "Temple",
          "rating": "9.8/10 Wonderful (3,009 reviews)",
          "rate": 9.8
        },
        {
          "name": "Gwalior",
          "info": "Gwalior is a historic city located in the state of Madhya Pradesh. Popular because of the hilltop fort, Gwalior is full of palaces and glorious temples giving this city a majestic charm which speaks volumes of its glorious past. A historic city founded by king Surajesan, Gwalior is a city where India's most eminent royalty once resided. Jai Vilas Pala has the largest carpet in the world which took almost 12 years to weave and two most massive chandeliers in the world that weight close to 3.5 tonnes.",
          "images": "https://www.holidify.com/images/bgImages/GWALIOR.jpg",
          "price": 5850,
          "package": "3 Nights / 4 Days",
          "category": "Fort",
          "rating": "7.2/10 Very Good (716 reviews)",
          "rate": 7.2
        }
      ]
    },
    {
        "id": "11",
        "location": "Goa",
        "capital": "Panji",
        "img": "https://www.holidify.com/images/bgImages/GOA.jpg",
        "place": [
          {
            "name": "Calangute Beach",
            "info": "Situated 15 km from Panjim, Calangute Beach is the longest beach in North Goa, stretching from Candolim to Baga. Due to its sheer size and popularity, it is a hub for tourists and backpackers from all over the world. Popular as the 'Queen of Beaches', the Calangute Beach of Goa is among the top ten bathing beaches in the world. Being one of the busiest and most commercial beaches of Goa, it is swarming with eating joints, shacks and clubs serving cocktails, beer and seafood. The Calangute Beach is also known for its water sports activities like parasailing, water surfing, banana ride and jet-skiing.",
            "images": "https://www.holidify.com/images/cmsuploads/compressed/shutterstock_1314723038_20190822145625.jpg",
            "price": 7500,
            "package": "2 Nights / 3 Days",
            "category": "Beach",
            "rating": "8.2/10 Excellent (989 reviews)",
            "rate": 9.1
          },
          {
            "name": "Aguada Fort",
            "info": "Fort Aguada is a 17th-century Portuguese fort looking out at the confluence of Mandovi River and the Arabian Sea. The crumbling ramparts of the fort stand on the Sinquerim Beach, approximately 18 km from Panjim. The highlight of the fort is a lone four-storey lighthouse (which is one-of-its-kind in Asia )and a stunning view of the sunset. Built-in 1612 as a protection from Dutch and Marathas, Fort Aguada was the most prized and crucial fort for the Portuguese and covers the entire peninsula at the southwestern tip of Bardez. The fort is so named after the Portuguese Word for water i.e. 'Agua' and used to be a replenishing source of freshwater for sailors. In fact, it has the capacity to hold 2,376,000 gallons of water and was one of the biggest freshwater reservoirs of Asia.",
            "images": "https://goa-tourism.org.in/images/places-to-visit/headers/fort-aguada-goa-entry-fee-timings-holidays-reviews-header.jpg",
            "price": 11500,
            "package": "3 Nights / 4 Days",
            "category": "Fort",
            "rating": "9.2/10 Wonderful (1,009 reviews)",
            "rate": 9.2
          },
          {
            "name": "Mangeshi Temple",
            "info": "Mangeshi Temple or Shri Mangueshi Temple is Lord Shiva temple located in the Mangeshi village in Ponda region of Goa. The largest and most visited temple in Goa, it is built in the honour of Bhagwan Manguesh, the Kuldevata of Gaud Saraswat Brahmins. The deity is believed to be an incarnation of Lord Shiva, whose name was derived from 'Mam Girisha' the words used by Goddess Parvati when Lord Shiva made a successful attempt to scare her by taking the form of a Tiger.",
            "images": "https://lh3.googleusercontent.com/p/AF1QipOHjuu1A6c5MdUGV20pBmhC_b0UH083H_Aw04UM=s680-w680-h510",
            "price": 23000,
            "package": "2 Nights / 3 Days",
            "category": "Temple",
            "rating": "9.8/10 Wonderful (3,009 reviews)",
            "rate": 9.8
          },
          {
            "name": "Salaulim Dam",
            "info": "About two decades ago, Goa added to its long list of attractions the Salaulim Dam. While it was set up to contribute to the state’s irrigation & drinking water supply systems, the modern-day engineering marvel has scope to develop into a tourist attraction.",
            "images": "https://curlytales.com/wp-content/uploads/2019/01/YouTube-1-e1548166794938.jpg",
            "price": 12000,
            "package": "2 Nights / 3 Days",
            "category": "Dam",
            "rating": "7.2/10 Very Good (716 reviews)",
            "rate": 7.2
          },
          {
            "name": "Galgibaga Beach",
            "info": "Galgibaga Beach is one of Goa's most scenic beaches located on the banks of Galgibag river in Cancona, South Goa. Along with its unspoilt natural charm, it is also one of the three beaches of Goa known to be a nesting site for the Olive Ridley turtles. This pristine beach has often been termed as one of the cleanest beaches in India.",
            "images": "https://www.holidify.com/images/cmsuploads/compressed/shutterstock527215069cropped1574839354_20200808162625.jpg",
            "price": 31000,
            "package": "3 Nights / 4 Days",
            "category": "Beach",
            "rating": "7.2/10 Very Good (716 reviews)",
            "rate": 7.2
          }
        ]
      }
  ]